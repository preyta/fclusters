1. 每个||隔开每个节点的孩子
2. 若没有孩子就为空
3. 我觉得实在是不太可视化。。。。

ps refrence  scipy,numpy,pandas
